/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package bean;

import entity.Category;
import entity.Item;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author HP
 */
@Named(value = "ManageBean")
@SessionScoped
public class ManageBean implements Serializable {

    @PersistenceContext(unitName = "JSF_JWD_CRUDPU")
    private EntityManager em;
    @Resource
    private javax.transaction.UserTransaction utx;
    
    
    
    public ManageBean() {
    }

    public void persist(Object object) {
        try {
            utx.begin();
            em.persist(object);
            utx.commit();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }
    
    //Category
    
    int category_id;
    String category_name;

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
    
    public List<Category> getAllCategory(){
        List<Category> getAllCategory = em.createNamedQuery("Category.findAll").getResultList();
        return getAllCategory;
    }
    
    public String addCategory(){
        try{
            Category category = new Category();
            category.setCategoryId(category_id);
            category.setCategoryName(category_name);
            utx.begin();
            em.persist(category);
            utx.commit();
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return "category.jsf?faces-redirect=true";
    }
    
    public String searchCategory(int cid){
        Category category = em.find(Category.class, cid);
        category_id = category.getCategoryId();
        category_name = category.getCategoryName();
        
        return "update_category.jsf?faces-redirect=true";
    }
    
    public String updateCategory(){
        try{
            Category category = em.find(Category.class, category_id);
            category.setCategoryName(category_name);
            utx.begin();
            em.merge(category);
            utx.commit();
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return "category.jsf?faces-redirect=true";
    }
    
    public void deleteCategory(int category_id){
        try{
            Category category = em.find(Category.class, category_id);
            utx.begin();
            Category category1 = em.merge(category);
            em.remove(category1);
            utx.commit();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    //For Category Search Or Report
    
    List<Category> c;

    public List<Category> getC() {
        return c;
    }

    public void setC(List<Category> c) {
        this.c = c;
    }

    
    
    public void getRecord(){
        try{
            c = em.createNamedQuery("Category.findByCategoryName").setParameter("category_name", category_name).getResultList();
            category_name="";
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    //Item
    int item_id;
    String item_name;

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }
    
    public List<Item> getAllItem(){
        List<Item> getAllItem = em.createNamedQuery("Item.findAll").getResultList();
        return getAllItem;
    }
    
    public String addItem(){
        try{
            Item item = new Item();
            item.setItemName(item_name);
            Category category = em.find(Category.class, category_id);
            item.setCategoryId(category);
            utx.begin();
            em.persist(item);
            utx.commit();
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return "item.jsf?faces-redirect=true";
    }
    
    public String searchItem(int iid){
        Item item = em.find(Item.class, iid);
        item_id = item.getItemId();
        item_name = item.getItemName();
        category_id = item.getCategoryId().getCategoryId();
        
        
        return "update_item.jsf?faces-redirect=true";
    }
    
    public String updateItem(){
        try{
            Item item = em.find(Item.class, item_id);
            item.setItemName(item_name);
            Category category = em.find(Category.class, category_id);
            item.setCategoryId(category);
            utx.begin();
            em.merge(item);
            utx.commit();
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return "item.jsf?faces-redirect=true";
    }
    
    public void deleteItem(int item_id){
        try{
            Item item = em.find(Item.class, item_id);
            utx.begin();
            Item item1 = em.merge(item);
            em.remove(item1);
            utx.commit();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
    //For Item Search Or Report
    List<Item> i;

    public List<Item> getI() {
        return i;
    }

    public void setI(List<Item> i) {
        this.i = i;
    }

    
    
    
    
    
}
