package barberaapi.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import com.nitgen.SDK.BSP.NBioBSPJNI;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Collection;
import java.util.Properties;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;

/**
 *
 * @author
 */
@Path("rest")
public class JakartaEE8Resource {

    NBioBSPJNI bsp; // Declare NBioBSPJNI Class Object

    public JakartaEE8Resource() {
        // bsp = new NBioBSPJNI(); // Create NBioBSPJNI Class Object
    }

    public class FingerprintData {

        int id;
        String name;
        String TextFir;
    }

    @GET
    @Path("enroll")
    @Produces("application/json")
    public Response enrollFingerprint(FingerprintData fingerprintData) {
        try {
            bsp = new NBioBSPJNI(); // Create NBioBSPJNI Class Object

            if (bsp.OpenDevice() != 0) {
                fingerprintData.TextFir = "Failed to open device";
            }

            NBioBSPJNI.FIR_HANDLE hCapturedFIR;
            hCapturedFIR = bsp.new FIR_HANDLE();
            bsp.Enroll(hCapturedFIR, null); // Enroll

            if (bsp.Capture(hCapturedFIR) != 0) {
                fingerprintData.TextFir = "Failed to capture fingerprint";
            }

            NBioBSPJNI.FIR_TEXTENCODE textCapturedFIR;
            textCapturedFIR = bsp.new FIR_TEXTENCODE();
            bsp.GetTextFIRFromHandle(hCapturedFIR, textCapturedFIR);
            fingerprintData.TextFir = textCapturedFIR.TextFIR;

            return Response.status(200).entity(fingerprintData).build();
        } catch (Exception ex) {
            return Response.status(400).entity(ex).build();
        }

    }

    @GET
    @Path("ping")
    public Response ping() {
        return Response
                .ok("ping")
                .build();
    }
}
